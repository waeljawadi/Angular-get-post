export interface Items {
     id:number,
     email:string,
     password:string,
     n_choisie:number
}
