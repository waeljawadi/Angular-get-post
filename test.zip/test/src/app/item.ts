export class Itemmm {


  constructor
  (
    public id:number,
    public email:string,
    public password:string,
    public n_choisie:number
){}
}
